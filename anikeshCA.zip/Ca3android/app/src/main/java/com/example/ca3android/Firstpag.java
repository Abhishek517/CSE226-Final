package com.example.ca3android;

public interface Firstpag {
}
